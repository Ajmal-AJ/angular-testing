import { Component } from '@angular/core';

@Component({
  selector: 'app-navabar',
  standalone: true,
  imports: [],
  templateUrl: './navabar.component.html',
  styleUrl: './navabar.component.scss'
})
export class NavabarComponent {

}
